import React, { useState } from "react";
import { homeData } from "./homeData";
import "./homeStyle.css";

function Home() {
  const [showMore, setShowMore] = useState(false);

  const sportsImage = "src/imageFolder/sports.jpeg";

  // Clicking the button reverses the vaule of the state.
  function toggleReadMore() {
    setShowMore((prevShowMore) => !prevShowMore);
  }
  // Mapping over each element which is an outer key.
  // Extracting the outer keys.
  // Iterating over each key and value. The key conditionally renders the class name string while the value renders the HTML content.
  function renderParagraphs(showMore) {
    return homeData.map((element, index) => {
      const { primary, secondary } = element;
      return (
        <div key={index}>
          {primary && primary.className === "primary-text" && (
            <p className="primary-text">{primary.text}</p>
          )}
          {secondary &&
            secondary.className === "secondary-text" &&
            showMore && <p className="secondary-text">{secondary.text}</p>}
        </div>
      );
    });
  }

  return (
    <>
      <div className="home">
        <h1>Join the team!</h1>
        <img src={sportsImage} alt="sport image" />
        <h2>Company</h2>
        <div className="text">{renderParagraphs(showMore)}</div>
        <button onClick={toggleReadMore}>
          {showMore ? "Read Less" : "Read More"}
        </button>
      </div>
    </>
  );
}

export default Home;
