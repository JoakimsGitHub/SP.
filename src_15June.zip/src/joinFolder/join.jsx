import React, { useContext, useState } from "react";
import "./joinStyle.css";
import Modal from "../modalFolder/modal";
import { modalText } from "../modalFolder/modalData";
import { ClientContext } from "../context/genericContext.jsx";
import { joinInputFields } from "../inputFieldFolder/inputFieldData.jsx";
import InputField from "../inputFieldFolder/inputField";
import Payment from "../paymentFolder/payment.jsx";

function Join() {
  const { clientDetails, setClientDetails } = useContext(ClientContext);
  const [modal, setModal] = useState(false);
  const [isCheckBoxMarked, setCheckBoxMarked] = useState(false);
  const [checkboxAnimation, setCheckboxAnimation] = useState(false);
  const [isOfAge, setIsOfAge] = useState(false);

  // Function to handle changes in input fields.
  function handleChange(event) {
    const { name, value } = event.target;
    console.log(event.timeStamp); // Logging the timestamp of the event
    setClientDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value,
    }));
  }

  // The .current property is used to persist a value across rendering the component.
  // This ensures that this useEffect runs only once when the component mounts.

  // Function to handle checkbox change.
  function handleCheckboxChange(event) {
    setCheckBoxMarked(event.target.checked);
  }

  // Function to handle form submission.
  function handleSubmit(event) {
    event.preventDefault();

    const isUserOfAge = checkAge();
    const allFieldsFilled = checkAllFieldsFilled();

    const message = !allFieldsFilled
      ? "Please complete filling in your details."
      : !isCheckBoxMarked
        ? "Please agree to the terms and conditions."
        : !isUserOfAge
          ? "You must be 18 years of age to join."
          : null;

    displayMessage(message);

    // if (isUserOfAge && isCheckBoxMarked && allFieldsFilled) {
    //   console.log(clientDetails); // Logging client details upon successful submission
    //   // Perform form submission logic here
    // } else {
    //   if (!allFieldsFilled) {
    //     displayMessage("Please complete filling in your details.");
    //   } else if (!isCheckBoxMarked) {
    //     displayMessage("Please agree to the terms and conditions.");
    //     setCheckboxAnimation(true); // Trigger checkbox animation
    //     setTimeout(() => {
    //       setCheckboxAnimation(false); // Reset checkbox animation after delay
    //     }, 500);
    //   } else if (!isUserOfAge) {
    //     displayMessage("You must be 18 years of age to join.");
    //   }
    // }
  }

  // Function to check if all input fields are filled.
  function checkAllFieldsFilled() {
    return Object.keys(joinInputFields).every(
      (key) => clientDetails[key] && clientDetails[key].trim() !== "",
    );
  }

  // Event handler for updating the setIsOfAge setter function.
  // Checking if the client is above 18 years of age by comparing the exact time when the client turns 18.
  // The date object doesn't allow method chaining. The difference in year, month and day must be calculated using separate logic.
  function checkAge() {
    if (!clientDetails || !clientDetails.dob) {
      return false; // Handling case where date of birth is not set
    }

    const dateOfBirth = new Date(clientDetails.dob);
    const today = new Date();
    // Set date when user turns 18, checking both year, month, day, hour, minute and second for accuracy. The client can join the very moment they turn 18.
    const legalAgeDate = new Date(
      dateOfBirth.getFullYear() + 18,
      dateOfBirth.getMonth(),
      dateOfBirth.getDate(),
    );

    // Comparing today's date with legalAgeDate.
    const isOfAge = today.getTime() >= legalAgeDate.getTime();
    // setIsOfAge(isOfAge);
    display;
    return isOfAge;
  }

  // Alert: displays a dialog box with a message and an OK button.
  // It's used to show informational messages.
  function displayMessage(message) {
    alert(message); // Displaying an alert dialog with the provided message
  }

  // Function to toggle modal visibility.
  function showModal() {
    setModal((prevModal) => !prevModal); // Toggling the modal state
  }

  // Dynamic button class based on checkbox animation state.
  const buttonClass = checkboxAnimation ? "buttonAnimated" : "buttonStatic";

  // Text constants for the form and checkboxes.
  const fillInRequest = "Please fill in your details";
  const displayedName =
    clientDetails && clientDetails.firstname
      ? clientDetails.firstname.charAt(0).toUpperCase().trim() +
        clientDetails.firstname.slice(1).trim()
      : "";
  const agreeText = "I agree to the ";
  const termsAndConditionsText = "terms and conditions";

  return (
    <div>
      <div className="headingContainer">
        <h1 className="headingText">Join Now</h1>
      </div>
      <form className="form1" onSubmit={handleSubmit}>
        <h2>
          {fillInRequest}
          {displayedName && `, ${displayedName}`}
        </h2>
        <InputField
          joinInputFields={joinInputFields}
          handleChange={handleChange}
        />
        <div>
          <Payment />
        </div>
        <div className="checkbox">
          <input
            id="input2"
            type="checkbox"
            checked={isCheckBoxMarked}
            onChange={handleCheckboxChange}
          />
          <label htmlFor="input2">{agreeText}</label>
          <div className="termsContainer" onClick={showModal}>
            <p id="termsAndConditions">{termsAndConditionsText}</p>
          </div>
        </div>
        {/* The showModal function is passed as event handler to the onClick event listener. */}
        {modal && <Modal modalText={modalText} showModal={showModal} />}
        {/* Dynamic class name for button based on checkbox animation */}
        <button className={buttonClass} type="submit">
          Submit
        </button>
      </form>
    </div>
  );
}

export default Join;
