import React, { useState, useEffect } from "react";

// toLocaleTimeString: method that converts a date object to a string, using locale-specific conventions.
// Takes 2 parameters: locale and options.
// Locales: a string(s) with a BCP 47 language tag. It specifies the locale to use.
// Options: an object with properties to customize the output. These values can be `"numeric", `2-digit`, `narrow`, `short`, `long`, `full`, `day`, `weekday`, `month.`, `year`, `timeZoneName`, `hour`, `minute`, `second`, `hour12`, `dayPeriod`.

function Clock() {
    const timeOptions = {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        timeZoneName: "short",
        hour12: true,
        timeZone: "Europe/Stockholm",
    };

    const [ctime, setcTime] = useState(
        new Date().toLocaleTimeString("en-US", timeOptions));
    const [currentDayString, setCurrentDayString] = useState("");

    const updatedSecond = new Date().getSeconds
    useEffect(() => {
        const interval = setInterval(() => {
            const newTime = new Date();
            setcTime(newTime.toLocaleTimeString("en-US", timeOptions));
            setCurrentDayString(dayList[newTime.getDay()]);
        }, 1000);

        return () => clearInterval(interval); // Cleanup interval on component unmount
    }, [updatedSecond]);

    const dayList = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
    ];

    return (
        <>
            <div className="clock">
                {currentDayString} {ctime}
            </div>
        </>
    );
}

export default Clock;
