import React, { useState } from "react";
import { homeData } from "./homeData";
import "./homeStyle.css";

function Home() {
  const [showMore, setShowMore] = useState(false);

  const sportsImage = "src/imageFolder/sports.jpeg";

  // Clicking the button reverses the vaule of the state.
  function toggleReadMore() {
    setShowMore((prevShowMore) => !prevShowMore);
  }

  // Creating an array of the entries (keys and values) of the object.)
  // Destructuring the extracted keys and values.
  // Iterating over each key and value. The key conditionally renders the class name string while the value renders the HTML content.

  // Source alternative 1: array of objects.
  export const homeData = [
    {
      text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
      className: "primary-text",
    },
    {
      text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
      className: "secondary-text",
    },
  ];

  // Function alternative 1 for source alternative 1: rendering paragraphs based on the showMore state.
  function renderParagraphs(showMore) {
    return homeData.map((element, index) => {
      const { className, text } = element;
      return (
        <div key={index}>
          {className === "primary-text" && (
            <p className="primary-text">{text}</p>
          )}
          {className === "secondary-text" && showMore && (
            <p className="secondary-text">{text}</p>
          )}
        </div>
      );
    });
  }

  // Function alternative 2 for source alternative 1: rendering paragraphs based on the showMore state.
  function renderParagraphs() {
    return homeData.map((element, index) => {
      const { className, text } = element;
      return (
        <div key={index}>
          {!showMore && className === "primary-text" && (
            <p className="primary-text">{text}</p>
          )}
          {showMore && (
            <>
              {className === "primary-text" && (
                <p className="primary-text">{text}</p>
              )}
              {className === "secondary-text" && (
                <p className="secondary-text">{text}</p>
              )}
            </>
          )}
        </div>
      );
    });
  }

  // Source alternative 2: structured as an array of object of subobjects. Adds complexity due to the nested structure. Least preffered.
  export const homeData = [
    {
      primary: {
        text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
        className: "primary-text",
      },
    },
    {
      secondary: {
        text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
        className: "secondary-text",
      },
    },
  ];

  // Function alternative 1 for source alternative 2: rendering paragraphs based on the showMore state using a switch statement.
  function renderParagraphs(showMore) {
    return homeData.map((element, index) => {
      const { className, text } = element;
      switch (className) {
        case "primary-text":
          return (
            <div key={index} className={className}>
              {!showMore && <p>{text}</p>}
            </div>
          );
        case "secondary-text":
          return (
            <div key={index} className={className}>
              {showMore && <p>{text}</p>}
              {showMore && <p>{text}</p>}
            </div>
          );
        default:
          return null;
      }
    });
  }

  // Function alternative 2 for source alternative 2.
  function renderParagraphs(showMore) {
    return homeData.map((element, index) => {
      const key = Object.keys(element)[0];
      const { className, text } = element[key];

      return (
        <div key={index}>
          {className === "primary-text" && (
            <p className="primary-text">{text}</p>
          )}
          {className === "secondary-text" && showMore && (
            <p className="secondary-text">{text}</p>
          )}
        </div>
      );
    });
  }
  // Function alternative 3 for source alternative 2.
  function renderParagraphs(showMore) {
    return homeData.map((element, index) => {
      const { primary, secondary } = element;

      return (
        <div key={index}>
          {primary && primary.className === "primary-text" && (
            <p className="primary-text">{primary.text}</p>
          )}
          {secondary &&
            secondary.className === "secondary-text" &&
            showMore && <p className="secondary-text">{secondary.text}</p>}
        </div>
      );
    });
  }

  // Source alternative 3: structured as an object of objects. This is the best approach in terms of readability, reusability and conciseness.
  export const homeData = {
    primary: {
      text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
      className: "primary-text",
    },
    secondary: {
      text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
      className: "secondary-text",
    },
  };

  // Function alternative 1 to source alternative 3. Iterating over the keys of the object and creating JSX elements accordingly.
  function renderParagraphs(showMore) {
    return Object.keys(homeData).map((key, index) => {
      const { text, className } = homeData[key];
      for (const key in homeData) {
        // Additional processing with the for...in loop if needed
      }
      return (
        <div key={index}>
          {className === "primary-text" && (
            <p className="primary-text">{text}</p>
          )}
          {className === "secondary-text" && showMore && (
            <p className="secondary-text">{text}</p>
          )}
        </div>
      );
    });
  }
  // Function alternative 2 to source alternative 3. Iterating over the keys of the object and creating JSX elements accordingly.
  function renderParagraphs(showMore) {
    const entries = Object.entries(homeData);

    return entries.map(([key, value], index) => {
      const { text, className } = value;

      return (
        <div key={index}>
          {className === "primary-text" && (
            <p className="primary-text">{text}</p>
          )}
          {className === "secondary-text" && showMore && (
            <p className="secondary-text">{text}</p>
          )}
        </div>
      );
    });
  }

  return (
    <div className="home">
      <h1>Join the team!</h1>
      <img src={sportsImage} alt="sport image" />
      <h2>Company</h2>
      <div className="text">{renderParagraphs(showMore)}</div>
      <button onClick={toggleReadMore}>
        {showMore ? "Read Less" : "Read More"}
      </button>
    </div>
  );
}

export default Home;
