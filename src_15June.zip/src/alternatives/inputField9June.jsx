import React from "react";

function InputField({ field }) {



  // Source alternative 1: objects of object.

  export const joinInputField = {
    firstname: {
      label: "Your firstname: ",
      type: "text",
      name: "firstname",
      placeholder: "Please enter your firstname",
    },
    surname: {
      label: "Your surname: ",
      type: "text",
      name: "surname",
      placeholder: "Please enter your surname",
    },
    email: {
      label: "Your email: ",
      type: "text",
      name: "email",
      placeholder: "Please enter your email address",
    },
    phone: {
      label: "Your phone#: ",
      type: "text",
      name: "phone",
      placeholder: "Please enter your phone number",
    },
  };

  const inputFieldArray = Object.keys(field);

  // Function alternative 1 to source alternative 1: extracting (object deconstructing) each key of each key-value pair of each object (element).
  // Directly accessing the keys of each object (element) directly without extraction.
  function renderInputFields() {
    return inputFieldArray.map((inputField) => (
      <div key={inputField}>
        <label htmlFor={inputField}>{field[inputField].label}</label>
        <input
          type={field[inputField].type}
          name={field[inputField].name}
          placeholder={field[inputField].placeholder}
        />
      </div>
    ));
  }

  // Function alternatve 2 to source alternative 1: extracting (object deconstructing) each key of each key-value pair of each object (element).
  // Using a temporary variable to store the object.
  function renderInputFields() {
    return inputFieldArray.map((inputFieldKey) => {
      const inputField = field[inputFieldKey];
      return (
        <div key={inputFieldKey}>
          <label htmlFor={inputField.name}>{inputField.label}</label>
          <input
            type={inputField.type}
            name={inputField.name}
            placeholder={inputField.placeholder}
          />
        </div>
      );
    });
  }

  


  
  // Source alternative 2: array of objects.
  export const joinInputField = [
    {
      label: "Your firstname: ",
      type: "text",
      name: "firstname",
      placeholder: "Please enter your firstname",
    },
    {
      label: "Your surname: ",
      type: "text",
      name: "surname",
      placeholder: "Please enter your surname",
    },
    {
      label: "Your email: ",
      type: "text",
      name: "email",
      placeholder: "Please enter your email address",
    },
    {
      label: "Your phone#: ",
      type: "text",
      name: "phone",
      placeholder: "Please enter your phone number",
    },
  ];

  // Function alternative 1 to source alternative 2:
  function InputField({ field }) {
    function renderInputFields() {
      return field.map((inputField, index) => (
        <div key={index}>
          <label htmlFor={inputField.name}>{inputField.label}</label>
          <input
            type={inputField.type}
            name={inputField.name}
            placeholder={inputField.placeholder}
          />
        </div>
      ));
    }



  return <div className="inputFields">{renderInputFields()}</div>;
}

export default InputField;


  