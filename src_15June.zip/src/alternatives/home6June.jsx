import React, { useState } from "react";
import { homeData } from "./homeData";
import "./homeStyle.css";

function Home() {
  const [showMore, setShowMore] = useState(false);

  const sportsImage = "src/imageFolder/sports.jpeg";

  // Clicking the button reverses the vaule of the state.
  function toggleReadMore() {
    setShowMore((prevShowMore) => !prevShowMore);
  }

  // Iterating over the key values, as array elements, and rendering their them as HTML elements.
  function renderParagraphs() {
    for (const value of Object.values(homeData)) {
      return;

      <p className={(value = key[0] ? "primaryText" : "secondaryText")}>
        {value}
      </p>;
    }
  }

  return (
    <div className="home">
      <h1>Join the team!</h1>

      <img src={sportsImage} alt="sport image" />
      <h2>Company</h2>
      <div className="text">{renderParagraphs()}</div>
      <p>{homeData.homeText}</p>
      {showMore && (
        <p className="additionalText">{homeData.additionalHomeText}</p>
      )}
      <button onClick={toggleReadMore}>
        {showMore ? "Read Less" : "Read More"}
      </button>
    </div>
  );
}

export default Home;
