// Returning an array of objects with team data.
export const basketballScore = [
    {
        team: "Manchester United",
        p: 31,
        w: 24,
        d: 13,
        l: 15,
        gd: 44,
        pts: 73,
    },
    {
        team: "Liverpool FC",
        p: 29,
        w: 28,
        d: 15,
        l: 22,
        gd: 52,
        pts: 62,
    },
    {
        team: "FC Bayern München",
        p: 39,
        w: 23,
        d: 26,
        l: 19,
        gd: 49,
        pts: 81,
    },
];

