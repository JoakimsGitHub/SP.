import React from "react";

function InputField({ joinInputFields, handleChange }) {
  const inputFieldArray = Object.keys(joinInputFields);

  // Extracting (object deconstructing) each key of each key-value pair of each object (element).
  // Directly accessing the keys of each object (element) directly without extraction.
  function renderInputFields() {
    return inputFieldArray.map((inputFieldKey) => {
      const inputField = joinInputFields[inputFieldKey];
      return (
        <div key={inputFieldKey}>
          <label htmlFor={inputField.name}>{inputField.label}</label>
          <input
            type={inputField.type}
            name={inputField.name}
            placeholder="Please enter here"
            onChange={handleChange} 
          />
        </div>
      );
    });
  }

  return <div className="inputFields">{renderInputFields()}</div>;
}

export default InputField;
