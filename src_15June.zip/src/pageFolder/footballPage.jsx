import React from "react";

import Football from "../sportFolder/football.jsx";

function FootballPage() {
  return (
    <>
      <Football />
    </>
  );
}

export default FootballPage;
