import React from "react";
import { whoAndWhat } from "./aboutData";
import "./aboutStyle.css";

function About() {
  // whoAndWhat is an array of nested objects.
  // For each array element, destructure the first key-value pair to get the inner object. This returns an array of the outer keys.


// Source alternative 1: the data structure is an array of nested objects.
  export const whoAndWhat = [
    {
      whoWeAre: {
        heading: "Who we are",
        paragraph:
          "Best Referee fielder soccer striker one-two goalie yellow card center-half three-five-two goal Hire Cup of Nations pitch forward number 10 brace. Three-five-two referee hat trick forward one-two halftime number 10 goalie pitch goal midfielder defender ball UEFA.",
      },
    },
    {
      whatWeDo: {
        heading: "What we do",
        paragraph:
          "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA European Championship ball one-two upper 90 pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half Cup of Nations soccer brace chip upper 90 ball four-four-two.",
      },
    },
  ];

  // Function alternative 1 to source alternative 1:
  function renderAbout() {
    const outerEntries = Object.entries(whoAndWhat);
    return outerEntries.map(([outerValue], outerIndex) => { // Array destructuring each outer key-value pair.
      const innerEntries = Object.entries(outerValue);
      return (
        <div key={outerIndex}>
          {innerEntries.map(([innerValue], innerIndex) => ( // Array destructuring each inner key-value pair.
            <div key={innerIndex}>
              <h2>{innerValue.heading}</h2>
              <p>{innerValue.paragraph}</p>
            </div>
          ))}
        </div>
      );
    });
  }

  // Source alternative 2: the data structure is an array of objects with direct properties.
  export const whoAndWhat = [
    {
      heading: "Who we are",
      paragraph: "Best Referee fielder soccer striker one-two goalie yellow card center-half three-five-two goal Hire Cup of Nations pitch forward number 10 brace. Three-five-two referee hat trick forward one-two halftime number 10 goalie pitch goal midfielder defender ball UEFA.",
    },
    {
      heading: "What we do",
      paragraph: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA European Championship ball one-two upper 90 pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half Cup of Nations soccer brace chip upper 90 ball four-four-two.",
    },

    // Function alternative 1 to source alternative 2: directly destructures the nested object's properties from each object of the array.
    function renderAbout() {
      return whoAndWhat.map((element, index) => {
        const { heading, paragraph } = element; // Object destructuring the key-value pairs of each element.
        return (
          <div key={index}>
            <h2>{heading}</h2>
            <p>{paragraph}</p>
          </div>
        );
      });
    }
  

// Function alternative 2 to source alternative 2:
  function renderAbout() {
    return whoAndWhat.map((element, index) => (
      <div key={index}>
        {Object.values(element).map((nestedContent, nestedIndex) => (
          <div key={nestedIndex}>
            <h2>{nestedContent.heading}</h2>
            <p>{nestedContent.paragraph}</p>
          </div>
        ))}
      </div>
    ));
  }
  

  return (
    <div className="about">
      <h1>Support your team!</h1>
      <div className="whoAndWhat">{renderAbout()}</div>
    </div>
  );
}

export default About;
