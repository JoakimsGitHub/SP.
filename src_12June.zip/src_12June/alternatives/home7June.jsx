import React, { useState } from "react";
import "./homeStyle.css";

function Home() {
  const [showMore, setShowMore] = useState(false);

  const sportsImage = "src/imageFolder/sports.jpeg";

  // Clicking the button reverses the vaule of the state.
  function toggleReadMore() {
    setShowMore((prevShowMore) => !prevShowMore);
  }

  // Creating an array of the entries (keys and values) of the object.)
  // Destructuring the extracted keys and values.
  // Iterating over each key and value. The key conditionally renders the class name string while the value renders the HTML content.

  // Source alternative 1: homeData is structured as an array of objects of subobjects.
  // A nested structure gives more code complexity.
  export const homeData = [
    {
      primary: {
        text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
        className: "primaryText",
      },
    },
    {
      secondary: {
        text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
        className: "secondaryText",
      },
    },
  ];
  
  // Function alternative 1 for source alternative 1:
  function renderParagraphs() {
    return homeData.map((element, index) => {
      const [key, value] = Object.entries(element)[0]; // Extract both the key and the value from the elements (keys)
      const { text, className } = value;
      return (
        <div key={index}>
          {!showMore && className === "primaryText" && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
          {showMore && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
        </div>
      );
    });
  }
  
// Function alternative 2 for source alternative 1:
  function renderParagraphs() {
    return homeData.map((element, index) => {
      const [value] = Object.values(element); // Just extracting the value from the elements (keys).
      const { text, className } = value;
      return (
        <div key={index}>
          {!showMore && className === "primaryText" && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
          {showMore && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
        </div>
      );
    });
  }

  // Function alternative 3 for source alternative 1:
  function renderParagraphs() {
    return homeData.map((element, index) => {
      const [{ text, className }] = Object.values(element); // Directly extracting the text and className from the nested object, omitting value of the elements (keys)
      return (
        <div key={index}>
          {!showMore && className === "primaryText" && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
          {showMore && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
        </div>
      );
    });
  }
  
  // Function alternative 4 for source alternative 1: 
  function renderParagraphs() {
    return homeData.map((element, index) => {
      const { text, className } = element;
      return (
        <div key={index}>
          {!showMore && className === "primaryText" && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
          {showMore && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
        </div>
      );
    });
  }

  // Function alternative 5 for source alternative 1: 
  // Mapping over each element (key) and accessing the elements' values using dot notation, without first extracting the value as new variable.
  function renderParagraphs() {
    return homeData.map((element, index) => {
      return (
        <div key={index}>
          {!showMore && element.className === "primaryText" && (
            <div className={element.className}>
              <p>{element.text}</p>
            </div>
          )}
          {showMore && (
            <div className={element.className}>
              <p>{element.text}</p>
            </div>
          )}
        </div>
      );
    });
  }
  
// Source alternative 2: homeData is structured as an array of objects.
  // This structure is more scalable and easily extended with additional nested properties. 
// Is less verbose. 
  export const homeData = [
    { text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.", className: "primaryText",
      },
    {
      { text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!", className: "secondaryText",
      },
    },
  ];

  // Function alternative 1 for source alternative 2:
  // This is the better choice because of its simpler data structure and direct property access. 
  function renderParagraphs() {
    return homeData.map((element, index) => {
      const className = element.className;
      const text = element.text;
      return (
        <div key={index}>
          {!showMore && className === "primaryText" && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
          {showMore && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
        </div>
      );
    });
  }



// Source alternative 3: structured as an object of subobjects. 
  export const homeData = {
    primary: {
      text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
      className: "primaryText",
    },
    secondary: {
      text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
      className: "secondaryText",
    },
  };


  // Function alternative 1 for source alternative 2:
  // This is the better choice because of its simpler data structure and direct property access. 
  // Since an literal object is not a iterable object, the map method is not used. A new array is created and is returned.
  function renderParagraphs() {
    const paragraphs = [];
    for (const key in homeData) {
      const { text, className } = homeData[key];
      paragraphs.push(
        <div key={key}>
          {!showMore && className === "primaryText" && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
          {showMore && (
            <div className={className}>
              <p>{text}</p>
            </div>
          )}
        </div>
      );
    }
    return paragraphs;
  }
  

  export const homeData = {
    textFirst: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
    classNameFirst: "primaryText",
    textSecond: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
    classNameSecond: "secondaryText",
  };

  function renderParagraphs() {
    for (const key in homeData) {
      switch (key) {
        case "textFirst":
          return (
            <div key={key}>
              {!showMore && homeData.classNameFirst === "primaryText" && (
                <div className={homeData.classNameFirst}>
                  <p>{homeData.textFirst}</p>
                </div>
              )}
              {showMore && (
                <div className={homeData.classNameFirst}>
                  <p>{homeData.textFirst}</p>
                </div>
              )}
            </div>
          );
        case "classNameFirst":
          // Handle classNameFirst case
          break;
        case "textSecond":
          // Handle textSecond case
          break;
        case "classNameSecond":
          // Handle classNameSecond case
          break;
        default:
          // Handle default case
          break;
      }
    }
  }

  

  return (
    <div className="home">
      <h1>Join the team!</h1>

      <img src={sportsImage} alt="sport image" />
      <h2>Company</h2>
      <div className="text">{renderParagraphs()}</div>
      <button onClick={toggleReadMore}>
        {showMore ? "Read Less" : "Read More"}
      </button>
    </div>
  );
}

export default Home;
