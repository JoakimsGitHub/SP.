import React from "react";

import About from "../aboutFolder/about.jsx";

function AboutPage() {
  return (
    <>
      <About />
    </>
  );
}

export default AboutPage;
