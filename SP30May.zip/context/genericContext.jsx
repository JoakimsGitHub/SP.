import React, { createContext, useState } from "react";

// Using the contest API for managing and sharing dynamic states across multiple components.
// An alternative to exporting importing variables from a module or passing down props through props drilling.

// Creating context objects using createContext().
export const ClientContext = createContext();

// Defining the context.
export function ContextProvider({ children }) {
  // Initializing local state variables.
  const [clientDetails, setClientDetails] = useState({
    firstname: "",
    surname: "",
    email: "",
    phone: "",
  });

  return (
    // Wrapping the consumer components within the provider component, as property of the context object, that use the provider component's state variable and updater function as props, passed as an object.
    <ClientContext.Provider value={{ clientDetails, setClientDetails }}>
      {children}
    </ClientContext.Provider>
  );
}
