import React from "react";

function NoPage() {
  return <h1> Error 404: Not found</h1>;
}
export default NoPage;
