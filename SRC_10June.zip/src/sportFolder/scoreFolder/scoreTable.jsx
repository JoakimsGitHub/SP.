import React, { useContext } from "react";
import ScoreData from "./scoreData.jsx";
import { scoreTableData } from "./scoreTableData.jsx";
import "../sportStyle.css";
import { ClientContext } from "../../context/genericContext.jsx";

function ScoreTable() {
  const { currentSport } = useContext(ClientContext);

  const scoreTable = scoreTableData[currentSport];

  const backgroundImage = scoreTable
    ? {
        backgroundImage: `url(${scoreTable.backgroundImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }
    : {};

  return (
    <div className="scoreTable">
      {scoreTable ? (
        <div className={currentSport} style={backgroundImage}>
          <section className={scoreTable.sectionClass}>
            <h2>{scoreTable.heading}</h2>
            <button>{scoreTable.buttonText}</button>
          </section>
          <section>
            <ScoreData />
          </section>
        </div>
      ) : (
        <div>No available table</div>
      )}
    </div>
  );
}

export default ScoreTable;
