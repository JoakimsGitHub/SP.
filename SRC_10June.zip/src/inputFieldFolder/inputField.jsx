import React from "react";

function InputField({ joinInputFields }) {
  const inputFieldArray = Object.keys(joinInputFields);

  // Alternative 1: extracting (object deconstructing) each key of each key-value pair of each object (element).
  // Directly accessing the keys of each object (element) directly without extraction.
  function renderInputFields() {
    return inputFieldArray.map((inputFieldKey) => {
      const inputField = joinInputFields[inputFieldKey];
      return (
        <div key={inputFieldKey}>
          <label htmlFor={inputField.name}>{inputField.label}</label>
          <input
            type={inputField.type}
            name={inputField.name}
            placeholder={inputField.placeholder}
          />
        </div>
      );
    });
  }

  return <div className="inputFields">{renderInputFields()}</div>;
}

export default InputField;
