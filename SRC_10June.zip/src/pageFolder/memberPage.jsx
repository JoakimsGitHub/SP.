import React from "react";

import Member from "../memberFolder/member.jsx";

function MemberPage() {
  return (
    <>
      <Member />
    </>
  );
}

export default MemberPage;
