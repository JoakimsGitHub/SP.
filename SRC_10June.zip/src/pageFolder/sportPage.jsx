import React, { useContext } from "react";
import SportCard from "../sportFolder/sportCard.jsx";
import SportSection from "../sportFolder/sportSection.jsx";
import { sportCardData } from "../sportFolder/sportCardData";
import { ClientContext } from "../context/genericContext.jsx";
import "./pageStyle.css";

function SportPage() {
  const { currentSport, setSport } = useContext(ClientContext); 

  function renderContent() {
    if (currentSport === "") {
      return renderLandingSection();
    } else {
      return renderSportSection();
    }
  }

  function renderLandingSection() {
    return (
      <div className="landing">
        {sportCardData.map((cardData, index) => (
          <div key={index}>
            <SportCard
              key={index}
              sport={cardData.sport}
              isApplicable={cardData.isApplicable}
              isAvailable={cardData.isAvailable}
              image={cardData.image}
              buttonText={cardData.buttonText}
            />
            <button onClick={() => setSport(cardData.sport)}>
              Explore {cardData.sport}
            </button>
          </div>
        ))}
      </div>
    );
  }

  function renderSportSection() {
    return (
      <div className="sport">
        <SportSection />
      </div>
    );
  }

  return <div className="sportPage">{renderContent()}</div>;
}

export default SportPage;
