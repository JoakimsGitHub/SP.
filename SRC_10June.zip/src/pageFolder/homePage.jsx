import React from "react";

import Home from "../homeFolder/home.jsx";

function HomePage() {
  return (
    <>
      <Home />
    </>
  );
}

export default HomePage;
