import React from "react";

function InputField({ joinInputFields, handleFieldChange }) {
  const inputFieldArray = Object.keys(joinInputFields);

  // Extracting (object deconstructing) each key of each key-value pair of each object (element).
  // Directly accessing the keys of each object (element) directly without extraction.
  // The inputFieldKey is the outer key. 
  // The inputField is each inner key. 
  function renderInputFields() {
    return inputFieldArray.map((inputFieldKey) => {
      const inputField = joinInputFields[inputFieldKey];
      return (
        <div key={inputFieldKey}>
          <label htmlFor={inputField.name}>{inputField.label}</label>
          <input
            type={inputField.type}
            name={inputField.name}
            placeholder="Please enter here"
            onChange={handleFieldChange} 
          />
        </div>
      );
    });
  }

  return <div className="inputFields">{renderInputFields()}</div>;
}

export default InputField;
