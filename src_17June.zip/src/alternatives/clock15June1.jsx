import { useState, useEffect } from "react";
import "./hfsStyle.css";

function Clock() {

    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const interval = setInterval(() => {
            setTime(new Date());
        }, 1000);
        return () => clearInterval(interval); // Clean up interval on component unmount
    }, []);

    const currentDayOfTheWeek = time.getDay();
    
    let currentHour = time.getHours();
    const currentMinute = time.getMinutes();
    const currentSecond = time.getSeconds();
    
    function getTimeOfDay(currentHour, currentMinute, currentSecond) {
        let prepend = currentHour >= 12 ? "PM" : "AM";
        if (currentHour === 0) {
            if (currentMinute === 0 && currentSecond === 0) {
                currentHour = 12;
                prepend = "Midnight";
            } else {
                currentHour = 12;
                prepend = "AM";
            }
        } else if (currentHour === 12) {
            if (currentMinute === 0 && currentSecond === 0) {
                prepend = "Noon";
            } else {
                prepend = "PM";
            }
        } else {
            currentHour = currentHour >= 12 ? currentHour - 12 : currentHour;
        }
        return { currentHour, prepend };
    }
    
    const dayList = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
    ];




    // Calling the function with these arguments, destructuring its returned object and storing its keys as new variables.
    const { currentHour: adjustedHour, prepend } = getTimeOfDay(
        currentHour,
        currentMinute,
        currentSecond,
    );

    // const clockClass = getHourClass(currentHour);

    const currentDayString = dayList[currentDayOfTheWeek];

    return (
        <>
            <div className="clock">
                {`${currentDayString} ${adjustedHour}:${currentMinute
                    .toString()
                    .padStart(
                        2,
                        "0",
                    )}:${currentSecond.toString().padStart(2, "0")} ${prepend}`}
            </div>
        </>
    );
}

export default Clock;
