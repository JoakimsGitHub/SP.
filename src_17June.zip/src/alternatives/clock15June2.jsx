import React, { useState, useEffect } from "react";
import "./hfsStyle.css";

function getHourClass(hour) {
    return hour >= 6 && hour < 18 ? "clockDay" : "clockNight";
}

function Clock() {
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
setClock();
    }, [currentSecond]);

    const currentDayOfTheWeek = currentTime.getDay();
    let currentHour = currentTime.getHours();
    const currentMinute = currentTime.getMinutes();
    const currentSecond = currentTime.getSeconds();

    function getTimeOfDay(currentHour, currentMinute, currentSecond) {
        let prepend = currentHour >= 12 ? "PM" : "AM";
        if (currentHour === 0) {
            if (currentMinute === 0 && currentSecond === 0) {
                currentHour = 12;
                prepend = "Midnight";
            } else {
                currentHour = 12;
                prepend = "AM";
            }
        } else if (currentHour === 12) {
            if (currentMinute === 0 && currentSecond === 0) {
                prepend = "Noon";
            } else {
                prepend = "PM";
            }
        } else {
            currentHour = currentHour >= 12 ? currentHour - 12 : currentHour;
        }
        return { currentHour, prepend };
    }

    const dayList = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
    ];

    const { currentHour: adjustedHour, prepend } = getTimeOfDay(
        currentHour,
        currentMinute,
        currentSecond,
    );

    const currentDayString = dayList[currentDayOfTheWeek];

function setClock(){
    setCurrentTime(`${currentDayString} ${adjustedHour}:${currentMinute
                      .toString()
                      .padStart(
                          2,
                          "0",
                      )}:${currentSecond.toString().padStart(2, "0")} ${prepend})
}

    function getCurrentTime(){

    }

    return (
        <>
            <div className="clock">{getCurrentTime()}</div>
        </>
    );
}

export default Clock;
