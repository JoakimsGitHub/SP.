// This function takes a sport string and returns an array of objects with team data.
// function setScoreData(sport) {
//     switch (sport) {
//         case "football":
//             return footballScore;
//         case "handball":
//             return handballScore;
//         case "basketball":
//             return basketballScore;
//         case "rugby":
//             return rugbyScore;
//         // Add cases for other sports if necessary
//         default:
//             return [];
//     }
// }

// // Destructuring the props object and setting its one property key as a new variable.
// const scoreData = setScoreData(sport);

// Mapping over each element object and rendering one <tr> for each.
// Mapping over each key-value pair of every element object and rendering one <td> for each.
// Setting the extracted key to be the value of the key attribute.
// Setting the extracted value to be the <td> element content.
// Each object is converted into an array och key-value pairs.

// Alternatve 2:
// Explicitly maps the properties to the table cells.
// Extracting the values of the inner key-value pair.
// function renderScore() {
//     return scoreData.map((value, index) => {
//         const {
//             sectionClass,
//             backgroundImage,
//             imageAlt,
//             heading,
//             buttonText,
//         } = value;
//         return (
//             <tr key={index}>
//                 <td>{sectionClass}</td>
//                 <td>{backgroundImage}</td>
//                 <td>{imageAlt}</td>
//                 <td>{heading}</td>
//                 <td>{buttonText}</td>
//             </tr>
//         );
//     });
// }

import React, { useContext } from "react";
import { scoreTableData, scoreTableHeaders } from "./scoreTableData";
import { ClientContext } from "../../context/genericContext.jsx";
import "../sportStyle.css";

function ScoreData() {
    const { currentSport } = useContext(ClientContext);

    // Access the appropriate score data based on the sport
    const scoreTable = Array.isArray(scoreTableData[currentSport]?.table)
        ? scoreTableData[currentSport].table
        : []; // Ensure scoreData is an array

    // Function to render table headers
    function renderTableHeaders() {
        return scoreTableHeaders.map((header, index) => (
            <th key={index}>{header}</th>
        ));
    }

    // Function to render score data
    function renderScore() {
        return scoreData.map((teamScore, index) => {
            const innerEntries = Object.entries(teamScore);
            return (
                <tr key={index}>
                    {innerEntries.map(([innerKey, innerValue]) => (
                        <td key={innerKey}>{innerValue}</td>
                    ))}
                </tr>
            );
        });
    }

    // Render the score data table
    function renderTable() {
        return (
        <div className={currentSport} style={scoreData.backgroundImage}>
          <section className={scoreTable.sectionClass}>
            <h2>{scoreTable.heading}</h2>
            <button>{scoreTable.buttonText}</button>
          </section>
          <section>
                       <table className="scoreData">
                <caption>Score Table</caption>
                <thead>
                    <tr>{renderTableHeaders()}</tr>
                </thead>
                <tbody>{renderScore()}</tbody>
                <tfoot>
                    <tr>
                        <td colSpan={scoreTableHeaders.length}>
                            <div>Updated in real-time</div>
                        </td>
                    </tr>
                </tfoot>
            </table>
          </section>
        );
    }



        // Render the score data table or an error message if no matching sport
        return (
            scoreData.length === 0 ? <div>Invalid sport</div> : renderTable()
        );
    }

    export default ScoreData;