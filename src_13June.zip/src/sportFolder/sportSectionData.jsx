// An object containing an object for each sport, each containing two objects.

export const sportSectionData = {
  football: {
    sport: "football",
    image: "src/imageFolder/football.jpg",
  },
  handball: {
    sport: "handball",
    image: "src/imageFolder/handball.jpeg",
  },
  basketball: {
    sport: "basketball",
    image: "src/imageFolder/basketball.jpeg",
  },
  rugby: {
    sport: "rugby",
    image: "src/imageFolder/rugby.jpeg",
  },
};

