import React from "react";

import Join from "../joinFolder/join.jsx";

function JoinPage() {
  return (
    <>
      <Join />
    </>
  );
}

export default JoinPage;
