export const paymentMethods = {
  empty: "Select an option",
  visa: "Visa",
  mastercard: "Mastercard",
  giftcard: "Giftcard",
};

export default paymentMethods;
