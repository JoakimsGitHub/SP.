export const homeData = [
  {
    primary: {
      text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
      className: "primary-text",
    },
  },
  {
    secondary: {
      text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
      className: "secondary-text",
    },
  },
];

// export const homeData = [
//   {
//     text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
//     className: "primary-text",
//   },
//   {
//     text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
//     className: "secondary-text",
//   },
// ];

// export const homeData = [
//   { text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.", className: "primaryText",
//     },

//   {
//     { text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!", className: "secondaryText",
//     },
//   },
// ];

// export const homeData = {
//   primary: {
//     text: "European Championship four-four-two center-half brace. Center-half Cup of Nations red card chip goalie UEFA ball one-two upper 90.",
//     className: "primary-text",
//   },
//   secondary: {
//     text: "Pitch defender yellow card forward. Red card goalie one-two hat trick three-five-two halftime number 10 center-half!",
//     className: "secondary-text",
//   },
// };
