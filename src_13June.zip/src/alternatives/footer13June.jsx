import React, { useEffect, useRef } from "react";
import { useInView } from "react-intersection-observer";
import Clock from "./clock";
import { Link } from "react-router-dom";
import {
    externalLinks,
    presentation,
    copyright,
    contactInfo,
} from "./hfsData.jsx";
import "./hfsStyle.css";

// Containing additional content: presentation, copyright, company name, contact info, and links to external sources.
// For SEO purposes.
function Footer() {
    // Setting a boolean based on when an element, with a ref object as ref attribute value, is in view.
    // Detecting the visibility of an element as in entering or exiting the viewport (the visible part of the web page within the browser window). Allows for triggering animations by scroll position.
    // The useInView hook returns an object with the following properties:
    // ref: this object is applied to the element that is to be observed.
    // inView: a boolean value that indicates whether the element is visible or not.
    const { ref, inView, entry } = useInView({
        threshold: 0.1, // Trigger when x% of the element is visible.
        triggerOnce: false, // Only trigger once until the element enters the viewport again?
    });

    // Initializing audioRef as useRef without a parameter to manage the audio element.
    // Using a ref object to store the audio object.
    const audioRef = useRef(new Audio());

    const audioSources = {
        popUp: "src/hfsFolder/hsfAudio/popUpSFX.mp3",
        // Uncomment and add more sources if needed
        // notification: "src/audioFolder/notification.mp3",
        // alert: "src/audioFolder/alert.mp3",
    };

    useEffect(() => {
        if (inView) {
            // Play audio.
            // playAudio(popUpAudio)
            // playAudio(audioRef.current);
            // Passing one of the audio sources to the audio object.
            playAudio(audioSources.popUp);
            console.log("Element is in view. ");
        } else {
            console.log("Element is not in view. ");
        }
    }, [inView]); // Dependency array to ensure the function is only called when inView updates.

    function playAudio(newAudioSource) {
        // Checking if the current audioRef doesn not have the same value as the already passed value (if the passed file path is the same as the current file path). If that is true, assugn the new value to the audioRef.
        audioRef.current.src !== newAudioSource &&
            (audioRef.current.src = newAudioSource);
        // if (audioRef.current.src !== newAudioSource) {
        //     audioRef.current.src = newAudioSource;
        // }
        // Play audio if it exists
        audioRef?.current?.play?.();
        // Set currentTime and stop if it's 0.5 seconds
        // audioRef?.current?.currentTime === 0.2 && audioRef?.current?.pause?.();
        // Pause when currentTime reaches 0.5 seconds
        // audioRef?.current?.addEventListener?.(
        //     "timeupdate",
        //     function checkTime() {
        //         if (audioRef?.current?.currentTime >= 0.5) {
        //             audioRef?.current?.pause?.();
        //             audioRef?.current?.removeEventListener?.(
        //                 "timeupdate",
        //                 checkTime,
        //             );
        //         }
        //     },
        // );
    }

    // Function to render a series of external links.
    // The key attribute determines the uniqueness of each element as an identifier.
    // Accessing the keys of each object (element) directly without extraction.
    function renderLinks() {
        return externalLinks.map((link, index) => (
            <Link to={link.url} key={index}>
                {link.site}
            </Link>
        ));
    }

    function renderContactInfo() {
        return contactInfo.map((info, index) => (
            <div key={index}>
                <p>{info.text}</p>
                <img src={info.icon} alt={info.alt}></img>
            </div>
        ));
    }

    // For each array element, create one term and one definition HTML element and let their contents be the values of each key.
    function renderPresentation() {
        return presentation.map((text, index) => (
            <div key={index}>
                <dt>{text.dt}</dt>
                <dd>{text.dd}</dd>
            </div>
        ));
    }

    // Applying CSS rules inline by setting property values to the style attribute.

    // Alternative 1: conditional object. Using a keyframe animation.
    // Setting the keyframe animation property if inView is true and setting the opacity property if false.
    // const inViewAnimation = inView
    //     ? { animation: "fadeIn 1s ease-in-out" }
    //     : { opacity: 0 };

    // Alternative 2: static object. Using a CSS transition.
    // Fixed transition property value and sets the opacity property to 0 if inView is false.
    const inViewAnimation = {
        transition: "opacity 1s ease-in-out",
        opacity: inView ? 1 : 0,
    };
    // The return value of the function is a style object, containing the property values of the style attribute.
    // Call the function embedded in the style attribute with the inView as parameter.
    function fadeInElement(inView) {
        return {
            transition: "opacity 1s ease-in-out",
            opacity: inView ? 1 : 0,
        };
    }

    return (
        <>
            <footer>
                <hr />
                {/* Using the ref object (obtained from useInView rather than useRef) as value of the ref attribute. The ref attribute is embedded into the element that is to have its visibility monitored. */}

                <div ref={ref} style={inViewAnimation || fadeInElement()}>
                    <div className="links-contact">
                        <div className="external-links">{renderLinks()}</div>
                        <div className="contact-info">
                            {renderContactInfo()}
                        </div>
                    </div>
                    <div className="presentation">{renderPresentation()}</div>
                    <div className="copyright">{copyright}</div>
                    <div className="clock-container">
                        <time>
                            <Clock />
                        </time>
                    </div>
                </div>
                {/* {inView ? (
                    <p>Element is in the viewport!</p>
                ) : (
                    <p>Element is not in the viewport...</p>
                )} */}
                {/* <audio ref={audioRef} controls /> */}
            </footer>
        </>
    );
}

export default Footer;
