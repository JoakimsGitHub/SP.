import React, { useContext } from "react";
import { scoreTableData, scoreTableHeaders } from "./scoreTableData";
import { ClientContext } from "../../context/genericContext.jsx";
import "../sportStyle.css";

// Merged the deprecated ScoreData component into this component.
function ScoreTable() {
  const { currentSport } = useContext(ClientContext);

  // Access the appropriate score data based on the sport.
  const scoreTable = scoreTableData[currentSport];
  // Ensure scoreData is an array using optional chaining (for safely accessing nested properties by checking its validity) and ternary operator.
  const scoreData = Array.isArray(scoreTable?.table) ? scoreTable.table : [];

  function renderHeaders() {
    return scoreTableHeaders.map((header, index) => (
      <th key={index}>{header}</th>
    ));
  }

  function renderScore() {
    return scoreData.map((teamScore, index) => {
      const innerEntries = Object.entries(teamScore);
      return (
        <tr key={index}>
          {innerEntries.map(([innerKey, innerValue]) => (
            <td key={innerKey}>{innerValue}</td>
          ))}
        </tr>
      );
    });
  }

  // CSS styling.
  // Using a ternary operator offers more explicitness since the two distinct cases being handled are very clear. More readable but becomes verbose when multiple conditions require nested ternaries (and thats when if-statements should be used).
  // function renderTable() {
  // const backgroundImage = scoreTable
  //   ? {
  //       backgroundImage: `url(${scoreTable.backgroundImage})`,
  //       backgroundSize: "cover",
  //       backgroundPosition: "center",
  //     }
  //   : {};

  // CSS styling.
  // Combining 3 types of conditional checking: optional chaining, nullish coalescing and ternary operating.
  // Optional chaining operator: checks if the value is null or undefined for safe property access. A better alternative to && since OCP will not short-circuit if the value returns as 0. Is a modern JS syntax.
  // Nullish coalescing operator: checks if the value is null or undefined and provides a default value. 
  // Ternary operator: checks if the value is true or false. 
  function renderTable() {
    const backgroundImage = {
      // Combining optional chaining operator with nullish coalescing operator.
      backgroundImage: `url(${scoreTable?.backgroundImage ?? ""})`,
      // Combining optional chaining operator with ternary operator.
      backgroundSize: scoreTable?.backgroundImage ? "cover" : "",
      backgroundPosition: scoreTable?.backgroundImage ? "center" : "",
    };

    return (
      <div style={backgroundImage}>
        <section className={scoreTable.sectionClass}>
          <h2>{scoreTable.heading}</h2>
          <button>{scoreTable.buttonText}</button>
        </section>
        <section>
          <table className="scoreData">
            <caption>Score Table</caption>
            <thead>
              <tr>{renderHeaders()}</tr>
            </thead>
            <tbody>{renderScore()}</tbody>
            <tfoot>
              <tr>
                <td colSpan={scoreTableHeaders.length}>
                  <div>Updated in real-time</div>
                </td>
              </tr>
            </tfoot>
          </table>
        </section>
      </div>
    );
  }

  // Render the score data table or an error message if no matching sport
  return (
    <div className="scoreTable">
      {scoreData.length === 0 ? <div>Invalid sport</div> : renderTable()}
    </div>
  );
}

export default ScoreTable;
