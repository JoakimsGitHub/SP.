import React from "react";
import { whoAndWhat } from "./aboutData";
import "./aboutStyle.css";

function About() {
  // For...in loop.
  // Iterating over each key for each item and checks if the iterated array element has the key in question.
  function renderAbout() {
    return whoAndWhat.map((item, index) => {
      for (const key in item) {
        if (item.hasOwnProperty(key)) {
          const content = item[key];
          return (
            <div key={index}>
              <h2>{content.heading}</h2>
              <p>{content.paragraph}</p>
            </div>
          );
        }
      }
    });
  }

  // Alternatively, iterating over the key-value pairs using object.entries.
  // function About() {
  //   function renderAbout() {
  //     return whoAndWhat.map((item, index) => {
  //       const [key, content] = Object.entries(item)[0];
  //       return (
  //         <div key={index}>
  //           <h2>{content.heading}</h2>
  //           <p>{content.paragraph}</p>
  //         </div>
  //       );
  //     });
  //   }

  return (
    <div className="about">
      <h1>Support your team!</h1>
      {renderAbout()}
    </div>
  );
}

export default About;
