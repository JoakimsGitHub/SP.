// ScoreData.js

import React from "react";
import footballScore from "./footballScore";
import handballScore from "./handballScore";
import basketballScore from "./basketballScore";
import rugbyScore from "./rugbyScore";
import "../sportStyle.css";

// This function takes a sport string and returns an array of objects with team data.
function setScoreData(sport) {
    switch (sport) {
        case "football":
            return footballScore;
        case "handball":
            return handballScore;
        case "basketball":
            return basketballScore;
        case "rugby":
            return rugbyScore;
        // Add cases for other sports if necessary
        default:
            return [];
    }
}

function ScoreData({ sport }) {
    const tableHeaders = ["Team", "P", "W", "D", "L", "GD", "PTS"];

    // Returning JSX elements directly.
    function renderTableHeaders() {
        return tableHeaders.map((header, index) => (
            <th key={index}>{header}</th>
        ));
    }

    // Destructuring the props object and setting its one property key as a new variable.
    const scoreData = setScoreData(sport);

    // Mapping over each element object and rendering one <tr> for each.
    // Mapping over each key-value pair of every element object and rendering one <td> for each.
    // Setting the extracted key to be the value of the key attribute.
    // Setting the extracted value to be the <td> element content.
    function renderScore() {
        return scoreData.map((teamScore, index) => (
            <tr key={index}>
                {Object.entries(teamScore).map(([key, value]) => (
                    <td key={key}>{value}</td>
                ))}
            </tr>
        ));
    }

    // No matching sport will return an empty array.
    if (scoreData.length === 0) {
        return <div>Invalid sport</div>;
    }

    return (
        <table className="scoreData">
            <thead>
                <tr>{renderTableHeaders()}</tr>
            </thead>
            <tbody>{renderScore()}</tbody>
        </table>
    );
}

export default ScoreData;
