import React from "react";
import { whoAndWhat } from "./aboutData";
import "./aboutStyle.css";

function About() {
  // whoAndWhat is an array of nested objects.
  // For each array element, destructure the first key-value pair to get the inner object. This returns an array of the outer keys.
  function renderAbout() {
    return whoAndWhat.map((element, index) => {
      const [key, nestedContent] = Object.entries(element)[0];
      return (
        <div key={index}>
          <h2>{nestedContent.heading}</h2>
          <p>{nestedContent.paragraph}</p>
        </div>
      );
    });
  }

  // Alternative 2:
  // function renderAbout() {
  //   return whoAndWhat.map((element, index) => (
  //     <div key={index}>
  //       {Object.values(element).map((nestedContent, nestedIndex) => (
  //         <div key={nestedIndex}>
  //           <h2>{nestedContent.heading}</h2>
  //           <p>{nestedContent.paragraph}</p>
  //         </div>
  //       ))}
  //     </div>
  //   ));
  // }

  return (
    <div className="about">
      <h1>Support your team!</h1>
      <div className="whoAndWhat">{renderAbout()}</div>
    </div>
  );
}

export default About;
